# CEC‑WAM Core (Organized Edition)

This repository contains a fully organized implementation of the **CEC‑WAM** platform, including both the browser‑based front‑end and a Python back‑end. The system provides a quantum‑themed dashboard for visualizing financial and operational metrics, as well as automated agents for data management and self‑healing.

## Contents

| Path | Description |
| --- | --- |
| `index.html` | The main user interface. It renders a 5D star field with a quantum planet, a PSI‑bound ship generator, a dimensional lattice, and an interactive timeline scrubber. A lock screen featuring EVE’s face must be dismissed using the wake code. |
| `app.py` | The Streamlit “brain” application. It provides a multi‑tab dashboard with command input, a simple star map, ledger metrics, and a live code editor for self‑healing. |
| `eve_agent.py` | A self‑contained agent that monitors disk usage and exports data safely when capacity limits are reached. |
| `formulas.md` | An immutable document defining core mathematical formulas such as the PSI mass, Black Hole flow rate, dark energy index, and capacity thresholds. |
| `data/ledger.csv` | A sample ledger recording asset activity and system checks. |
| `data/timeline.csv` | A sample timeline with key project milestones from November 6 2025 to January 17 2026. |
| `assets/EVE_FACE.png` | The canonical face of EVE used on the lock screen. |
| `assets/sounds/eve_wake.wav` | A simple wake sound played when the lock screen is dismissed. |
| `assets/sounds/eve_ack.wav` | A placeholder acknowledgement sound. |
| `exports/` | A folder where exported data snapshots will be stored when the cleanup agent runs. |

## Getting Started

1. Open `index.html` in a modern web browser to explore the quantum interface. Use the wake button (`1010_EVE_WAKE`) to unlock the UI. Adjust the timeline slider to scrub time and observe how the visuals respond. The PSI mass value drives the procedural ship geometry.
2. Run `app.py` with Streamlit (`streamlit run app.py`) to access the Python dashboard. The builder agent tab allows you to modify the code live from within the interface.
3. Execute `eve_agent.py` to perform a one‑time disk usage check and clean up the `data/` directory if capacity thresholds are exceeded.

## License

This project is provided for demonstration purposes. All included assets and scripts may be modified to fit your specific deployment or aesthetic needs.